let name = 'Mosh';
console.log(name);
